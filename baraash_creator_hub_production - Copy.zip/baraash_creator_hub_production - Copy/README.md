# Baraash Creator Hub

Deploy this folder to Vercel.

Routes:
- /sarah — Sarah's creator submission page
- /admin — admin login/dashboard

Before deployment:
1. Supabase Authentication -> Users -> Add your admin email/password.
2. Copy the user's UUID.
3. Replace YOUR-ADMIN-USER-UUID in admin_rls.sql.
4. Run admin_rls.sql in Supabase SQL Editor.
5. Deploy index.html to Vercel.
6. Add submit.baraash.com as the Vercel custom domain.
7. In Hostinger DNS, create the `submit` DNS record using the target Vercel provides.

The browser key in index.html is the public/publishable Supabase key. Never put a service-role/secret key in frontend code.
